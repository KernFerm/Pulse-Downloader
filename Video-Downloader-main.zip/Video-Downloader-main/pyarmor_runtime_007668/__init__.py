# Pyarmor 9.2.0 (pro), 007668, 2025-11-04T19:03:57.067547
from .pyarmor_runtime import __pyarmor__
